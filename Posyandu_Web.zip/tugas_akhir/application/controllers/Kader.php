<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kader extends CI_Controller
{

    public function template()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('template/beranda');
        $this->load->view('template/footer');
    }

    // public function home()
    // {

    //     $data = array(
    //         'chart' => json_encode($this->Madmin->grafik_imunisasi()),
    //         'anak_seluruh' => $this->Madmin->card_seluruh_anak(),
    //         'anak_rt1' => $this->Madmin->card_anak_rt1(),
    //         'anak_rt2' => $this->Madmin->card_anak_rt2(),
    //         'anak_rt3' => $this->Madmin->card_anak_rt3(),
    //         'anak_rt4' => $this->Madmin->card_anak_rt4(),
    //         'anak_rt5' => $this->Madmin->card_anak_rt5()
    //     );

    //     $this->load->view('template/header');
    //     $this->load->view('template/navbar_user');
    //     $this->load->view('admin/home', $data);
    //     $this->load->view('template/footer_admin');
    // }

    public function index()
    {
        $data = array(
            'chart' => json_encode($this->Madmin->grafik_imunisasi()),
            'anak_seluruh' => $this->Madmin->card_seluruh_anak(),
            'anak_rt1' => $this->Madmin->card_anak_rt1(),
            'anak_rt2' => $this->Madmin->card_anak_rt2(),
            'anak_rt3' => $this->Madmin->card_anak_rt3(),
            'anak_rt4' => $this->Madmin->card_anak_rt4(),
            'anak_rt5' => $this->Madmin->card_anak_rt5()
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/home', $data);
        $this->load->view('template/footer_admin');
    }

    public function menu_user()
    {
        $data = array(
            'user' => $this->Madmin->get_user()
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/menu_user', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_user()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_user');
        $this->load->view('template/footer_admin');
    }

    function post_user()
    {
        // $upload_image = $_FILES['image']['name'];

        // if ('$upload_image') {
        //     $config['allowed_types'] = 'gif|jpg|png';
        //     $config['max_size'] = '2048';
        //     $config['upload_path'] = './assets/img/user/';

        //     $this->load->library('upload', $config);

        //     if ($this->upload->do_upload('image')) {
        //         $new_image = $this->upload->data('file_name');
        //         $this->db->set('foto', $new_image);
        //     } else {
        //         echo $this->upload->display_errors();
        //     }
        // }

        $nama_user = $this->input->post('nama_user');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $no_telp = $this->input->post('no_telp');

        $data = array(
            'nama_user' => $nama_user,
            'username' => $username,
            'password' => $password,
            'no_telp' => $no_telp,
            'role_id' => '2',
            'is_active' => '1'
        );

        $this->Madmin->input_user($data);
        redirect('admin/menu_user');
    }

    public function edit_user()
    {
        $id = $this->input->get('id_user');
        $data = array(
            'id' => $id,
            'id_user' => $this->Madmin->get_id_user($id),
            'nama_user' => $this->Madmin->get_nama_user($id),
            'username' => $this->Madmin->get_username($id),
            'password' => $this->Madmin->get_password($id),
            'no_telp' => $this->Madmin->get_no_telp($id)
        );
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/edit_user', $data);
        $this->load->view('template/footer_admin');
    }

    public function update_user()
    {
        $id = $this->input->post('id_user');
        $data = array(
            'nama_user' => $this->input->post('nama_user'),
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
            'no_telp' => $this->input->post('no_telp')
        );

        $this->Madmin->update_user($data, $id);

        redirect('admin/menu_user', 'refresh');
    }

    function hapus_user()
    {
        $id_user = $this->input->get('id_user');

        $this->Madmin->hapus_user($id_user);
        redirect('admin/menu_user', 'refresh');
    }

    public function informasi_anak()
    {
        $data = array(
            'anak' => $this->Madmin->get_anak()
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/informasi_anak', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_anak()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_anak');
        $this->load->view('template/footer_admin');
    }

    function post_anak()
    {

        $nama_anak = $this->input->post('nama_anak');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $kelompok_rt = $this->input->post('kelompok_rt');

        $data = array(
            'nama_anak' => $nama_anak,
            'tgl_lahir' => $tgl_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'kelompok_rt' => $kelompok_rt
        );
        $this->Madmin->input_anak($data);

        $last_id = $this->db->insert_id();
        $imun = array(
            "id_anak" => $last_id
        );
        $tumbuh = array(
            "id_anak" => $last_id
        );

        $this->Madmin->input_id_imun($imun);
        $this->Madmin->input_id_tumbuh($tumbuh);
        redirect('admin/informasi_anak');
    }

    public function edit_anak()
    {
        $id = $this->input->get('id_anak');
        $data = array(
            'id' => $id,
            'id_anak' => $this->Madmin->get_id_anak($id),
            'nama_anak' => $this->Madmin->get_nama_anak($id),
            'tgl_lahir' => $this->Madmin->get_tgl_lahir($id),
            'jenis_kelamin' => $this->Madmin->get_jenis_kelamin($id),
            'kelompok_rt' => $this->Madmin->get_kelompok_rt($id),
            'nama_ayah' => $this->Madmin->get_nama_ayah($id),
            'nama_ibu' => $this->Madmin->get_nama_ibu($id),
            'username_ortu' => $this->Madmin->get_username_ortu($id),
            'password_ortu' => $this->Madmin->get_password_ortu($id)
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/edit_anak', $data);
        $this->load->view('template/footer_admin');
    }

    public function update_anak()
    {
        $id = $this->input->post('id_anak');
        $data = array(
            'nama_anak' => $this->input->post('nama_anak'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'kelompok_rt' => $this->input->post('kelompok_rt'),
            'nama_ayah' => $this->input->post('nama_ayah'),
            'nama_ibu' => $this->input->post('nama_ibu'),
            'username_ortu' => $this->input->post('username_ortu'),
            'password_ortu' => $this->input->post('password_ortu')
        );

        $this->Madmin->update_ortu($data, $id);

        redirect('admin/informasi_anak', 'refresh');
    }

    function hapus_anak()
    {
        $id_anak = $this->input->get('id_anak');

        $this->Madmin->hapus_anak($id_anak);
        $this->Madmin->hapus_imunisasi($id_anak);
        $this->Madmin->hapus_tumbuh_kembang($id_anak);
        redirect('admin/informasi_anak', 'refresh');
    }

    public function informasi_ortu()
    {
        $id_anak = $this->input->get('id_anak');
        $data = array(
            'anak' => $this->Madmin->get_ortu($id_anak)
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/informasi_ortu', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_ortu() //Edit Sebenarnya
    {
        $id = $this->input->get('id_anak');
        $data = array(
            'id' => $id,
            'id_anak' => $this->Madmin->get_id_anak($id),
            'nama_anak' => $this->Madmin->get_nama_anak($id),
            'tgl_lahir' => $this->Madmin->get_tgl_lahir($id),
            'jenis_kelamin' => $this->Madmin->get_jenis_kelamin($id),
            'kelompok_rt' => $this->Madmin->get_kelompok_rt($id),
            'nama_ayah' => $this->Madmin->get_nama_ayah($id),
            'nama_ibu' => $this->Madmin->get_nama_ibu($id),
            'username_ortu' => $this->Madmin->get_username_ortu($id),
            'password_ortu' => $this->Madmin->get_password_ortu($id)
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_ortu', $data);
        $this->load->view('template/footer_admin');
    }

    public function update_ortu()
    {
        $id = $this->input->post('id_anak');

        $id_anak = $this->Madmin->get_id_anak($id);

        $data = array(
            'nama_anak' => $this->input->post('nama_anak'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'kelompok_rt' => $this->input->post('kelompok_rt'),
            'nama_ayah' => $this->input->post('nama_ayah'),
            'nama_ibu' => $this->input->post('nama_ibu'),
            'username_ortu' => $this->input->post('username_ortu'),
            'password_ortu' => $this->input->post('password_ortu')
        );

        $this->Madmin->update_ortu($data, $id);

        redirect('admin/informasi_ortu?id_anak=' . $id_anak, 'refresh');
    }

    public function imunisasi()
    {
        $data = array(
            'imunisasi' => $this->Madmin->get_imunisasi()
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/imunisasi', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_imunisasi() //Edit Sebenarnya
    {
        $id = $this->input->get('id_imunisasi');
        $data = array(
            'id' => $id,
            'id_imunisasi' => $this->Madmin->get_id_imunisasi($id),
            'id_anak' => $this->Madmin->get_f_id_anak($id),
            'hbo' => $this->Madmin->get_hbo($id),
            'bcg' => $this->Madmin->get_bcg($id),
            'dpt_I' => $this->Madmin->get_dpt_I($id),
            'dpt_II' => $this->Madmin->get_dpt_II($id),
            'dpt_III' => $this->Madmin->get_dpt_III($id),
            'polio_I' => $this->Madmin->get_polio_I($id),
            'polio_II' => $this->Madmin->get_polio_II($id),
            'polio_III' => $this->Madmin->get_polio_III($id),
            'polio_IV' => $this->Madmin->get_polio_IV($id),
            'campak' => $this->Madmin->get_campak($id),
            'hepatitis_I' => $this->Madmin->get_hepatitis_I($id),
            'hepatitis_II' => $this->Madmin->get_hepatitis_II($id),
            'hepatitis_III' => $this->Madmin->get_hepatitis_III($id)
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_imunisasi', $data);
        $this->load->view('template/footer_admin');
    }



    public function update_imunisasi()
    {
        $id = $this->input->post('id_imunisasi');

        // $id_anak = $this->Madmin->get_id_imunisasi($id);

        $data = array(
            'id_anak' => $this->input->post('id_anak'),
            'hbo' => $this->input->post('hbo'),
            'bcg' => $this->input->post('bcg'),
            'dpt_I' => $this->input->post('dpt_I'),
            'dpt_II' => $this->input->post('dpt_II'),
            'dpt_III' => $this->input->post('dpt_III'),
            'polio_I' => $this->input->post('polio_I'),
            'polio_II' => $this->input->post('polio_II'),
            'polio_III' => $this->input->post('polio_III'),
            'polio_IV' => $this->input->post('polio_IV'),
            'campak' => $this->input->post('campak'),
            'hepatitis_I' => $this->input->post('hepatitis_I'),
            'hepatitis_II' => $this->input->post('hepatitis_II'),
            'hepatitis_III' => $this->input->post('hepatitis_III')
        );


        $this->Madmin->update_imunisasi($data, $id);

        redirect('admin/imunisasi', 'refresh');
    }


    public function tumbuh_kembang()
    {
        $id_anak = $this->input->get('id_anak');

        $data = array(
            'tumbuh_kembang' => $this->Madmin->fetch_tumbuhKembang(array("tk.id_anak" => $id_anak))
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/tumbuh_kembang', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_tumbuh() //Edit Sebenarnya
    {
        $id = $this->input->get('id_tumbuh');
        $tumbuh = $this->Madmin->getbyid("tumbuh_kembang", array("id_tumbuh_kembang" => $id));
        foreach ($tumbuh as $t) {

            $data = array(
                "id_tumbuh_kembang" => $t->id_tumbuh_kembang,
                "id_anak" => $t->id_anak,
                "bulan_0" => $t->bulan_0,
                "bulan_1" => $t->bulan_1,
                "bulan_2" => $t->bulan_2,
                "bulan_3" => $t->bulan_3,
                "bulan_4" => $t->bulan_4,
                "bulan_5" => $t->bulan_5,
                "bulan_6" => $t->bulan_6,
                "bulan_7" => $t->bulan_7,
                "bulan_8" => $t->bulan_8,
                "bulan_9" => $t->bulan_9,
                "bulan_10" => $t->bulan_10,
                "bulan_11" => $t->bulan_11,
                "bulan_12" => $t->bulan_12

            );
        }

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_tumbuh', $data);
        $this->load->view('template/footer_admin');
    }

    public function update_tumbuh()
    {
        $id = $this->input->post('id_tumbuh_kembang');


        $data = array(
            'id_anak' => $this->input->post('id_anak'),
            'bulan_0' => $this->input->post('bulan_0'),
            'bulan_1' => $this->input->post('bulan_1'),
            'bulan_2' => $this->input->post('bulan_2'),
            'bulan_3' => $this->input->post('bulan_3'),
            'bulan_4' => $this->input->post('bulan_4'),
            'bulan_5' => $this->input->post('bulan_5'),
            'bulan_6' => $this->input->post('bulan_6'),
            'bulan_7' => $this->input->post('bulan_7'),
            'bulan_8' => $this->input->post('bulan_8'),
            'bulan_9' => $this->input->post('bulan_9'),
            'bulan_10' => $this->input->post('bulan_10'),
            'bulan_11' => $this->input->post('bulan_11'),
            'bulan_12' => $this->input->post('bulan_12')
        );


        $this->Madmin->update_tumbuh($data, $id);

        redirect('admin/tumbuh_kembang?id_anak=' . $this->input->post('id_anak'), 'refresh');
    }

    public function grafik_tumbuh()
    {
        $id_tumbuh = $this->input->get('id_tumbuh');

        $data = array(
            'chart' => json_encode($this->Madmin->grafik($id_tumbuh))
        );

        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/grafik_tumbuh', $data);
        $this->load->view('template/footer_admin');
    }

    public function informasi_jadwal()
    {
        $data = array(
            'jadwal' => $this->Madmin->get_jadwal()
        );


        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/jadwal', $data);
        $this->load->view('template/footer_admin');
    }

    public function input_jadwal()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/input_jadwal');
        $this->load->view('template/footer_admin');
    }

    function post_jadwal()
    {

        $jadwal = $this->input->post('jadwal');
        $event = $this->input->post('event');

        $data = array(
            'jadwal' => $jadwal,
            'event' => $event
        );

        $this->Madmin->input_jadwal($data);
        redirect('admin/informasi_jadwal');
    }

    public function edit_jadwal()
    {
        $id = $this->input->get('id_jadwal');
        $data = array(
            'id' => $id,
            'id_jadwal' => $this->Madmin->get_id_jadwal($id),
            'jadwal' => $this->Madmin->get_jadwal_db($id),
            'event' => $this->Madmin->get_event($id)
        );
        $this->load->view('template/header');
        $this->load->view('template/navbar_user');
        $this->load->view('admin/edit_jadwal', $data);
        $this->load->view('template/footer_admin');
    }

    public function update_jadwal()
    {
        $id = $this->input->post('id_jadwal');
        $data = array(
            'jadwal' => $this->input->post('jadwal'),
            'event' => $this->input->post('event')
        );

        $this->Madmin->update_jadwal($data, $id);

        redirect('admin/informasi_jadwal', 'refresh');
    }

    function hapus_jadwal()
    {
        $id_jadwal = $this->input->get('id_jadwal');

        $this->Madmin->hapus_jadwal($id_jadwal);
        redirect('admin/informasi_jadwal', 'refresh');
    }
}
