<?php

class Madmin extends CI_Model
{
    function get_user()
    {
        $data = $this->db->query("
            SELECT 
                *
            FROM 
                user
            ");
        return $data->result_array();
    }

    function input_user($data)
    {
        $this->db->insert('user', $data);
    }

    function update_user($data, $id_user)
    {
        $this->db->where('id_user', $id_user);
        $q = $this->db->update('user', $data);

        return $q;
    }

    function hapus_user($id_user)
    {
        $q = $this->db->where('id_user', $id_user)->delete('user');
        return $q;
    }

    function get_anak()
    {
        $data = $this->db->query("
            SELECT 
                *
            FROM 
                anak
            ORDER BY
                id_anak
            ");
        return $data->result_array();
    }

    function hapus_anak($id_anak)
    {
        $q = $this->db->where('id_anak', $id_anak)->delete('anak');
        return $q;
    }

    function hapus_imunisasi($id_imunisasi)
    {
        $q = $this->db->where('id_anak', $id_imunisasi)->delete('imunisasi');
        return $q;
    }

    function hapus_tumbuh_kembang($id_tumbuh_kembang)
    {
        $q = $this->db->where('id_anak', $id_tumbuh_kembang)->delete('tumbuh_kembang');
        return $q;
    }

    function get_ortu($id_anak)
    {
        $data = $this->db->query("
            SELECT 
                *
            FROM 
                anak
            WHERE
                id_anak = '$id_anak'
            ");
        return $data->result_array();
    }

    function update_ortu($data, $id_anak)
    {
        $this->db->where('id_anak', $id_anak);
        $q = $this->db->update('anak', $data);

        return $q;
    }

    function input_anak($data)
    {
        $this->db->insert('anak', $data);
    }

    function input_id_imun($imun)
    {
        $this->db->insert('imunisasi', $imun);
    }

    function input_id_tumbuh($tumbuh)
    {
        $this->db->insert('tumbuh_kembang', $tumbuh);
    }

    function fetch_tumbuhKembang($data)
    {
        $this->db->select("*");
        $this->db->from("tumbuh_kembang tk");
        $this->db->join("anak a", "tk.id_anak = a.id_anak");
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result_array();
    }

    function get_imunisasi()
    {
        $data = $this->db->query("
            SELECT 
                i.id_imunisasi, a.id_anak, a.nama_anak, i.hbo, i.bcg, i.dpt_I, i.dpt_II, i.dpt_III, i.polio_I, i.polio_II, i.polio_III, i.polio_IV, i.campak, i.hepatitis_I, i.hepatitis_II, i.hepatitis_III 
            FROM 
                anak as a, imunisasi as i
            WHERE
                a.id_anak=i.id_anak
            ");
        return $data->result_array();
    }

    function update_imunisasi($data, $id_imunisasi)
    {
        $this->db->where('id_imunisasi', $id_imunisasi);
        $q = $this->db->update('imunisasi', $data);

        return $q;
    }

    function get_jadwal()
    {
        $data = $this->db->query("
            SELECT 
                *
            FROM 
                jadwal
            ");
        return $data->result_array();
    }

    function input_jadwal($data)
    {
        $this->db->insert('jadwal', $data);
    }

    function update_jadwal($data, $id_jadwal)
    {
        $this->db->where('id_jadwal', $id_jadwal);
        $q = $this->db->update('jadwal', $data);

        return $q;
    }

    function hapus_jadwal($id_jadwal)
    {
        $q = $this->db->where('id_jadwal', $id_jadwal)->delete('jadwal');
        return $q;
    }

    function getbyid($table, $data)
    {
        $this->db->select("*");
        $this->db->from($table);
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result();
    }

    function getbyid_hapus($table, $data)
    {
        $this->db->select("id_tumbuh_kembang");
        $this->db->from($table);
        $this->db->where($data);
        $query = $this->db->get();
        return $query->row("id_tumbuh_kembang");
    }

    function update_tumbuh($data, $id_tumbuh_kembang)
    {
        $this->db->where('id_tumbuh_kembang', $id_tumbuh_kembang);
        $q = $this->db->update('tumbuh_kembang', $data);

        return $q;
    }

    function grafik_imunisasi()
    {
        $q = $this->db->query("SELECT * FROM (
SELECT 'HBO' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE hbo IS NOT NUll union
SELECT 'BCG' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE bcg IS NOT NUll union
SELECT 'DPT I' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE dpt_I IS NOT NUll union
SELECT 'DPT II' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE dpt_II IS NOT NUll union
SELECT 'DPT III' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE dpt_III IS NOT NUll union
SELECT 'Polio I' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE polio_I IS NOT NUll union
SELECT 'Polio II' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE polio_II IS NOT NUll union
SELECT 'Polio III' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE polio_III IS NOT NUll union
SELECT 'Polio IV' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE polio_IV IS NOT NUll union
SELECT 'Campak' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE campak IS NOT NUll union
SELECT 'Hepatitis I' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE hepatitis_I IS NOT NUll union
SELECT 'Hepatitis II' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE hepatitis_II IS NOT NUll union
SELECT 'Hepatitis III' as country, COUNT(id_imunisasi) AS visits FROM imunisasi WHERE hepatitis_III IS NOT NUll 
)A
");

        return $q->result_array();
    }

    function grafik($id_tumbuh_kembang)
    {
        $q = $this->db->query("
        SELECT * FROM
			(
            SELECT bulan_0  income ,'Bulan 0'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_1  income ,'Bulan 1'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_2  income ,'Bulan 2'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_3  income ,'Bulan 3'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_4  income ,'Bulan 4'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_5  income ,'Bulan 5'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_6  income ,'Bulan 6'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_7  income ,'Bulan 7'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_8  income ,'Bulan 8'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
			SELECT bulan_9  income ,'Bulan 9'  as year FROM  tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
            SELECT bulan_10 income ,'Bulan 10' as year FROM tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
            SELECT bulan_11 income ,'Bulan 11' as year FROM tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang union
            SELECT bulan_12 income ,'Bulan 12' as year FROM tumbuh_kembang WHERE id_tumbuh_kembang = $id_tumbuh_kembang
            )A
        ");

        return $q->result_array();
    }

    function card_seluruh_anak()
    {
        $q = $this->db->query("
        SELECT count(*) as sa FROM anak
        ");

        return $q->row('sa');
    }

    function card_anak_rt1()
    {
        $q = $this->db->query("
        SELECT count(*) as a1 FROM anak where kelompok_rt = 1
        ");

        return $q->row('a1');
    }

    function card_anak_rt2()
    {
        $q = $this->db->query("
        SELECT count(*) as a2 FROM anak where kelompok_rt = 2
        ");

        return $q->row('a2');
    }

    function card_anak_rt3()
    {
        $q = $this->db->query("
        SELECT count(*) as a3 FROM anak where kelompok_rt = 3
        ");

        return $q->row('a3');
    }

    function card_anak_rt4()
    {
        $q = $this->db->query("
        SELECT count(*) as a4 FROM anak where kelompok_rt = 4
        ");

        return $q->row('a4');
    }

    function card_anak_rt5()
    {
        $q = $this->db->query("
        SELECT count(*) as a5 FROM anak where kelompok_rt = 5
        ");

        return $q->row('a5');
    }


    // GET ID TABEL USER

    public function get_id_user($id)
    {
        $q = $this->db->query("SELECT id_user FROM user WHERE id_user=$id");
        return $q->row()->id_user;
    }

    public function get_nama_user($id)
    {
        $q = $this->db->query("SELECT nama_user FROM user WHERE id_user=$id");
        return $q->row()->nama_user;
    }

    public function get_username($id)
    {
        $q = $this->db->query("SELECT username FROM user WHERE id_user=$id");
        return $q->row()->username;
    }

    public function get_password($id)
    {
        $q = $this->db->query("SELECT password FROM user WHERE id_user=$id");
        return $q->row()->password;
    }


    public function get_no_telp($id)
    {
        $q = $this->db->query("SELECT no_telp FROM user WHERE id_user=$id");
        return $q->row()->no_telp;
    }

    // GET ID TABEL ANAK

    public function get_id_anak($id)
    {
        $q = $this->db->query("SELECT id_anak FROM anak WHERE id_anak=$id");
        return $q->row()->id_anak;
    }

    public function get_nama_anak($id)
    {
        $q = $this->db->query("SELECT nama_anak FROM anak WHERE id_anak=$id");
        return $q->row()->nama_anak;
    }

    public function get_kelompok_rt($id)
    {
        $q = $this->db->query("SELECT kelompok_rt FROM anak WHERE id_anak=$id");
        return $q->row()->kelompok_rt;
    }

    public function get_tgl_lahir($id)
    {
        $q = $this->db->query("SELECT tgl_lahir FROM anak WHERE id_anak=$id");
        return $q->row()->tgl_lahir;
    }

    public function get_jenis_kelamin($id)
    {
        $q = $this->db->query("SELECT jenis_kelamin FROM anak WHERE id_anak=$id");
        return $q->row()->jenis_kelamin;
    }

    public function get_nama_ibu($id)
    {
        $q = $this->db->query("SELECT nama_ibu FROM anak WHERE id_anak=$id");
        return $q->row()->nama_ibu;
    }

    public function get_nama_ayah($id)
    {
        $q = $this->db->query("SELECT nama_ayah FROM anak WHERE id_anak=$id");
        return $q->row()->nama_ayah;
    }

    public function get_username_ortu($id)
    {
        $q = $this->db->query("SELECT username_ortu FROM anak WHERE id_anak=$id");
        return $q->row()->username_ortu;
    }

    public function get_password_ortu($id)
    {
        $q = $this->db->query("SELECT password_ortu FROM anak WHERE id_anak=$id");
        return $q->row()->password_ortu;
    }

    // GET Tabel Imunisasi

    public function get_id_imunisasi($id)
    {
        $q = $this->db->query("SELECT id_imunisasi FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->id_imunisasi;
    }

    public function get_f_id_anak($id)
    {
        $q = $this->db->query("SELECT id_anak FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->id_anak;
    }

    public function get_hbo($id)
    {
        $q = $this->db->query("SELECT hbo FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->hbo;
    }

    public function get_bcg($id)
    {
        $q = $this->db->query("SELECT bcg FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->bcg;
    }

    public function get_dpt_I($id)
    {
        $q = $this->db->query("SELECT dpt_I FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->dpt_I;
    }

    public function get_dpt_II($id)
    {
        $q = $this->db->query("SELECT dpt_II FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->dpt_II;
    }

    public function get_dpt_III($id)
    {
        $q = $this->db->query("SELECT dpt_III FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->dpt_III;
    }

    public function get_polio_I($id)
    {
        $q = $this->db->query("SELECT polio_I FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->polio_I;
    }
    public function get_polio_II($id)
    {
        $q = $this->db->query("SELECT polio_II FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->polio_II;
    }
    public function get_polio_III($id)
    {
        $q = $this->db->query("SELECT polio_III FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->polio_III;
    }
    public function get_polio_IV($id)
    {
        $q = $this->db->query("SELECT polio_IV FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->polio_IV;
    }
    public function get_campak($id)
    {
        $q = $this->db->query("SELECT campak FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->campak;
    }
    public function get_hepatitis_I($id)
    {
        $q = $this->db->query("SELECT hepatitis_I FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->hepatitis_I;
    }
    public function get_hepatitis_II($id)
    {
        $q = $this->db->query("SELECT hepatitis_II FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->hepatitis_II;
    }
    public function get_hepatitis_III($id)
    {
        $q = $this->db->query("SELECT hepatitis_III FROM imunisasi WHERE id_imunisasi=$id");
        return $q->row()->hepatitis_III;
    }

    // GET ID TABEL JADWAL

    public function get_id_jadwal($id)
    {
        $q = $this->db->query("SELECT id_jadwal FROM jadwal WHERE id_jadwal=$id");
        return $q->row()->id_jadwal;
    }

    public function get_event($id)
    {
        $q = $this->db->query("SELECT event FROM jadwal WHERE id_jadwal=$id");
        return $q->row()->event;
    }

    public function get_jadwal_db($id)
    {
        $q = $this->db->query("SELECT jadwal FROM jadwal WHERE id_jadwal=$id");
        return $q->row()->jadwal;
    }

    public function get_id_anak_tumbuh($id)
    {
        $q = $this->db->query("SELECT id_anak FROM tumbuh_kembang WHERE id_anak=$id");
        return $q->row()->id_anak;
    }
}
