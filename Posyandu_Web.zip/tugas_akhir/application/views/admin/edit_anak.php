<!-- Begin Page Content -->
<div class="container-fluid">


    <div class="card">
        <div class="card-header">
            <h5>
                Edit Data Bayi dan Balita
            </h5>
        </div>
        <div class="card-body">
            <!-- <h5 class="card-title"></h5> -->
            <form action="<?= base_url('admin/update_anak'); ?>" method="post" name="input_anak">

                <input type="hidden" class="form-control" id="id_anak" placeholder="" name="id_anak" value="<?= $id_anak ?>">

                <input type="hidden" class="form-control" id="nama_ayah" placeholder="" name="nama_ayah" value="<?= $nama_ayah ?>">

                <input type="hidden" class="form-control" id="nama_ibu" placeholder="" name="nama_ibu" value="<?= $nama_ibu ?>">

                <input type="hidden" class="form-control" id="username_ortu" placeholder="" name="username_ortu" value="<?= $username_ortu ?>">

                <input type="hidden" class="form-control" id="password_ortu" placeholder="" name="password_ortu" value="<?= $password_ortu ?>">

                <div class="form-group">
                    <label for="formGroupExampleInput">Nama Anak</label>
                    <input type="text" class="form-control" id="nama_anak" placeholder="" name="nama_anak" value="<?= $nama_anak ?>">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput">Tanggal Lahir</label>
                    <input type="date" class="form-control" id="tgl_lahir" placeholder="" name="tgl_lahir" value="<?= $tgl_lahir ?>">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput">Jenis Kelamin</label>
                    <select class="custom-select" name="jenis_kelamin">
                        <option value="<?= $jenis_kelamin ?>"><?= $jenis_kelamin ?></option>
                        <option>>-Pilih dibawah ini untuk mengganti-<</option> <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput">Kelompok RT</label>
                    <select class="custom-select" name="kelompok_rt">
                        <option value="<?= $kelompok_rt ?>"><?= $kelompok_rt ?></option>
                        <option>>-Pilih dibawah ini untuk mengganti-<</option> <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <input class="btn btn-primary float-right mt-3" type="submit" value="Submit">
            </form>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->