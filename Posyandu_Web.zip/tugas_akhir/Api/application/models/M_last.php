<?php

class M_last extends CI_Model{
    public function getIdObat(){
        return $this->db->query("SELECT * FROM obat ORDER BY id_obat DESC LIMIT 1")->result_array();
    }
}