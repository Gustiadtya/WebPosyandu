<?php

class M_obat extends CI_Model{
    public function getObat(){
        return $this->db->query("SELECT * FROM obat")->result_array();
    }
}