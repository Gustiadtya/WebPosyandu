<?php

class M_obat_ibumenyusui extends CI_Model{
    public function getObatIbuMenyusui(){
        return $this->db->query("SELECT * FROM obat WHERE kategori_pengguna='ibu menyusui' OR kategori_pengguna='ibu hamil dan menyusui'")->result_array();
    }
}