<?php

class M_forgot_password extends CI_Model{

    function forgotPassword($data){
        $query=$this->db->query("SELECT email, password FROM users WHERE email='$data'")->result_array();
       return $query;
    }
}