<?php

class M_register_users extends CI_Model{

    function registerUsers($data){
        $insert=$this->db->insert('users',$data);
        return $insert;
    }
}