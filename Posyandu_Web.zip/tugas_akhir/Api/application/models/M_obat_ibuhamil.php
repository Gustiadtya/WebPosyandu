<?php

class M_obat_ibuhamil extends CI_Model{
    public function getObatIbuHamil(){
        return $this->db->query("SELECT * FROM obat WHERE kategori_pengguna='ibu hamil' OR kategori_pengguna='ibu hamil dan menyusui'")->result_array();
    }
}