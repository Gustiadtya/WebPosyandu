<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Imunisasi extends CI_Controller
{
    use REST_Controller {
        REST_Controller::__construct as private __resTraitConstruct;
    }
    public function __construct()
    {
        parent::__construct();
        $this->__resTraitConstruct();
    }


    public function index_get()
    {
        $idanak = $this->get("id_anak");

        $get = $this->db->query("SELECT 
       * 
   FROM 
       imunisasi
   WHERE
       id_anak='$idanak'")->result_array();

        if ($get) {
            $this->response($get, 200);
        } else {
            $this->response(['Status' => "Failed"], 404);
        }
    }
}
