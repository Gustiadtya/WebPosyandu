<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Login extends CI_Controller
{
    use REST_Controller {
        REST_Controller::__construct as private __resTraitConstruct;
    }
    public function __construct()
    {
        parent::__construct();
        $this->__resTraitConstruct();
        $this->load->model('M_login');
    }


    public function index_post()
    {
        $username = $this->input->post('username_ortu');
        $password = $this->input->post('password_ortu');

        $where = array(
            'username_ortu' => $username,
            'password_ortu' => $password
        );
        $cek = $this->M_login->cek_login('anak', $where)->result_array();

        if (!empty($cek)) {
            $this->response([
                'status' => "Success",
                'data' => $cek
            ], 200);
        } else {
            $this->response([
                'status' => "Failed",
                'data' => $cek
            ], 404);
        }
    }
}
