<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Informasi_anak extends CI_Controller
{
    use REST_Controller {
        REST_Controller::__construct as private __resTraitConstruct;
    }
    public function __construct()
    {
        parent::__construct();
        $this->__resTraitConstruct();
    }


    public function index_get()
    {
        $username = $this->get("username_ortu");
        $password = $this->get("password_ortu");

        $get = $this->db->query("SELECT 
                
       i.id_imunisasi, a.id_anak, a.tgl_lahir,a.jenis_kelamin,a.nama_ayah,a.nama_ibu,a.nama_anak, i.hbo, i.bcg, i.dpt_I, i.dpt_II, i.dpt_III, i.polio_I, i.polio_II, i.polio_III, i.polio_IV, i.campak, i.hepatitis_I, i.hepatitis_II, i.hepatitis_III 
   FROM 
       anak as a, imunisasi as i
   WHERE
       a.id_anak=i.id_anak
   AND
       a.username_ortu = '$username' AND a.password_ortu = '$password'
       ")->result_array();

        if ($get) {
            $this->response($get, 200);
        } else {
            $this->response(['Status' => "Failed"], 404);
        }
    }
}
