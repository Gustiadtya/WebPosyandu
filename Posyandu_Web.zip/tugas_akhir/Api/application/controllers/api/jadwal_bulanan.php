<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Jadwal_Bulanan extends CI_Controller
{
    use REST_Controller {
        REST_Controller::__construct as private __resTraitConstruct;
    }
    public function __construct()
    {
        parent::__construct();
        $this->__resTraitConstruct();
    }


    public function index_get()
    {
        $get = $this->db->query("
        SELECT 
            * 
        FROM 
            jadwal 
        WHERE 
            YEAR(jadwal) = year(CURRENT_DATE()) AND MONTH(jadwal) = MONTH(CURRENT_DATE())
        ")->result_array();

        if ($get) {
            $this->response($get, 200);
        } else {
            $this->response(['Status' => "Failed"], 404);
        }
    }
}
