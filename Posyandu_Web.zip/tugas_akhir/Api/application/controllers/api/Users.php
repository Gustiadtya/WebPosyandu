<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Users extends CI_Controller
{
    use REST_Controller {
        REST_Controller::__construct as private __resTraitConstruct;
    }
    public function __construct()
    {
        parent::__construct();
        $this->__resTraitConstruct();
        $this->load->model('M_login');
    }
   
    
    public function index_post() 
    { 
        $username = $this->input->post('username'); 
        $password = $this->input->post('password'); 
        
        $where=array(
            'username' =>$username,
            'password'=>$password
        );
        $cek=$this->M_login->cek_login('users',$where)->result_array();
        
        if (!empty($cek)) {
            $this->response([
                'status' => "Success",
                'data' => $cek
            ], 200);         
        }
        else
        {
            $this->response([
                'status' => "Failed",
                'data' => $cek
            ], 404); 
        }
    }
    
    function index_put() {
        $id = $this->put('id_user');
        $data = array(
            'id_user' => $this->put('id_user'),
            'daily_login' => $this->put('daily_login'));
        $this->db->where('id_user', $id);
        $update = $this->db->update('users', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'Failed', 404));
        }
    }


}
